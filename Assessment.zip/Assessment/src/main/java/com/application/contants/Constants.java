package com.application.contants;

public class Constants {
	
	public static final int implicitWaitTime = 10;
	
	public static final int explicitWaitTime = 30;
	
}
