package com.application.testcases;

import com.application.utils.TestUtils;

public class RandomStringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println(TestUtils.generateRandomText());
	}

}
